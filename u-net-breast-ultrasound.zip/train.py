import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from model.unet_model import unet_model

# Dummy data untuk contoh (gunakan dataset asli untuk pelatihan)
# Dataset seharusnya di-folder 'data' dengan subfolder images dan masks
# Di sini hanya contoh struktur

input_shape = (256, 256, 1)
model = unet_model(input_shape)
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

print("Model summary:")
model.summary()
