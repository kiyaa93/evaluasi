# U-Net for Breast Ultrasound Segmentation

This is a simple implementation of U-Net for segmenting breast ultrasound images.

## Dataset
You can use the [BUSI Dataset](https://scholar.cu.edu.eg/?q=afahmy/pages/dataset). Put the dataset in the `data/` folder.

## Usage

### 1. Install Requirements
```bash
pip install -r requirements.txt
```

### 2. Train the Model
```bash
python train.py
```

## Output
The model will train and print a summary. Replace dummy data loading with real USG images and ground truth masks.

## Reference
- Ronneberger et al., 2015. U-Net: Convolutional Networks for Biomedical Image Segmentation
